document.getElementById('year').textContent = new Date().getFullYear();

document.querySelectorAll('.choose-service').forEach((button) => {
  button.addEventListener('click', () => {
    document.querySelector('select[name="service"]').value = button.dataset.service;
    document.getElementById('booking').scrollIntoView({ behavior: 'smooth' });
  });
});

const dateInput = document.querySelector('input[name="date"]');
const today = new Date();
const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
dateInput.min = localToday;

document.getElementById('booking-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData(form);
  const message = document.getElementById('form-message');
  message.textContent = `Thanks, ${data.get('name')}! This demo form is working, but real booking notifications are not connected yet.`;
  form.reset();
  dateInput.min = localToday;
});
